"""
Expose version
"""

__version__ = "3.1.0"
VERSION = __version__.split(".")
