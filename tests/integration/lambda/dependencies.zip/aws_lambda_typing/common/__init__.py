from .iam import PolicyDocument as PolicyDocument
